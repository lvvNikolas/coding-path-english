<?php
// Файлы phpmailer
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

// Переменные, которые отправляет пользователь
$name = $_POST['name'];
$phone = $_POST['phone'];
$age = $_POST['age'];
$comment = $_POST['comment'];
$noCall = $_POST['noCall'];
$agreement = $_POST['agreement'];

// Формирование самого письма
// $title = "Лид с сайта";
$body = "
<h2>Новое письмо</h2>
<b>Имя:</b> $name<br>
<b>Телефон:</b> $phone<br><br>
<b>Ученик:</b><br>$age<br><br>
<b>Комментарий:</b><br>$comment<br><br>
<b>Не звонить:</b><br>$noCall<br><br>
<b>Дал согласие на обработку:</b><br>$agreement<br><br>
";

// Настройки PHPMailer
$mail = new PHPMailer\PHPMailer\PHPMailer();
try {
    $mail->isSMTP();   
    $mail->CharSet = "UTF-8";
    $mail->SMTPAuth   = true;
    //$mail->SMTPDebug = 2;
    $mail->Debugoutput = function($str, $level) {$GLOBALS['status'][] = $str;};

    // Настройки вашей почты
    $mail->Host       = 'ssl://smtp.gmail.com'; // SMTP сервера вашей почты
    $mail->Username   = 'sendmailfromitchr@gmail.com'; // Логин на почте
    $mail->Password   = 'Itchrsite19993'; // Пароль на почте
    $mail->SMTPSecure = 'ssl';
    $mail->Port       = 465;
    $mail->setFrom('sendmailfromitchr@gmail.com', 'Заявка Крусова'); // Адрес самой почты и имя отправителя

    // Получатель письма
    $mail->addAddress('drony061093@gmail.com');  
    $mail->addAddress('u4icode@gmail.com'); // Ещё один, если нужен


// Отправка сообщения
$mail->isHTML(true);
$mail->Subject = $title;
$mail->Body = $body;    

// Проверяем отравленность сообщения
if ($mail->send()) {$result = "success";} 
else {$result = "error";}

} catch (Exception $e) {
    $result = "error";
    $status = "Сообщение не было отправлено. Причина ошибки: {$mail->ErrorInfo}";
}

// Отображение результата
echo json_encode(["result" => $result, "resultfile" => $rfile, "status" => $status]);
