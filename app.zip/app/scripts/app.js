//   all ------------------
// function initParadoxWay() {
//     "use strict";
   
//     if ($(".testimonials-carousel").length > 0) {
//         var j2 = new Swiper(".testimonials-carousel .swiper-container", {
//             preloadImages: false,
//             slidesPerView: 1,
//             spaceBetween: 20,
//             loop: true,
//             grabCursor: true,
//             mousewheel: false,
//             centeredSlides: true,
//             pagination: {
//                 el: '.tc-pagination',
//                 clickable: true,
//                 dynamicBullets: true,
//             },
//             navigation: {
//                 nextEl: '.listing-carousel-button-next',
//                 prevEl: '.listing-carousel-button-prev',
//             },
//             breakpoints: {
//                 1024: {
//                     slidesPerView: 3,
//                 },
                
//             }
//         });
//     }
    
// bubbles -----------------
    
    
//     setInterval(function () {
//         var size = randomValue(sArray);
//         $('.bubbles').append('<div class="individual-bubble" style="left: ' + randomValue(bArray) + 'px; width: ' + size + 'px; height:' + size + 'px;"></div>');
//         $('.individual-bubble').animate({
//             'bottom': '100%',
//             'opacity': '-=0.7'
//         }, 4000, function () {
//             $(this).remove()
//         });
//     }, 350);
    
// }

//   Init All ------------------
// $(document).ready(function () {
//     initParadoxWay();
// });



//ADVANTAGES SCRIPT
const advantagesNav = document.querySelectorAll('.advantagesItem')
const advantagesTextContainer = document.querySelector('.advantagesText')
let advantagesBgToggler = document.querySelector('.animation')
advantagesBgToggler.style.width = advantagesNav[0].offsetWidth + "px"
const advantagesTextContent = document.querySelectorAll('.advantagesItemText')
const advantagesDescriprionText = []
advantagesTextContent.forEach((e)=>{
    let obj = {
        text:e.innerHTML
    }
   advantagesDescriprionText.push(obj)
})
let currentChoosenAdv 
const leftCorner = document.querySelector('.animationLeft')
const rightCorner = document.querySelector('.animationRight')
advantagesTextContainer.innerHTML = advantagesDescriprionText[0].text
advantagesNav[0].classList.add('selectedText')

advantagesNav.forEach((e,j)=>{

    e.addEventListener('click',(event)=>{
        let newIndex = j
        console.log(newIndex)
        currentChoosenAdv  = j
        advantagesBgToggler.style.width = event.target.offsetWidth + "px"
        advantagesBgToggler.style.left = event.target.offsetLeft + "px"
        advantagesNav.forEach((e)=>{if(e.classList.contains('selectedText')){e.classList.remove('selectedText')}})
        event.target.classList.add('selectedText')
        advantagesTextContainer.innerHTML = advantagesDescriprionText[j].text
    })
})

window.addEventListener('resize',()=>{
  
        if(window.innerWidth > 950){
            if(currentChoosenAdv == undefined){
                currentChoosenAdv = 0
            }
            advantagesBgToggler.style.width = advantagesNav[currentChoosenAdv].offsetWidth + "px"
            advantagesBgToggler.style.left = advantagesNav[currentChoosenAdv].offsetLeft + "px"
        }
})
// END OF ADVANTAGES SCRIPT

//DIRECTION CARD HOVER
    const dirCard = document.querySelectorAll('.direction__button')
    dirCard.forEach((e)=>{
        e.addEventListener('mouseover', (event)=>{
            event.target.classList.add('direction__button--hovered')
        })
        e.addEventListener('mouseout', (event)=>{
            event.target.classList.remove('direction__button--hovered')
        })
        e.addEventListener('click', (event)=>{
            event.target.classList.remove('direction__button--hovered')
        })
    })

//DERICTION END OF CARD HOVER


//FORMCARD HOVER
const formBtn = document.querySelector('.form__submit-btn')
    formBtn.addEventListener('mouseover', (event)=>{
        event.target.classList.add('form__button--hovered')
    })
    formBtn.addEventListener('mouseout', (event)=>{
        event.target.classList.remove('form__button--hovered')
    })
    formBtn.addEventListener('click', (event)=>{
        event.target.classList.remove('form__button--hovered')
    })


//FORM END OF CARD HOVER


//FORM SEND DATA
const form = document.getElementById('form')
form.addEventListener('submit', sendForm)

async function sendForm(e){
    e.preventDefault()
    // Validator
    // let error = validateErrors(form)
   
    let formData = new FormData(form)
 
    // if(error === 0){
        //Add loader here
        let response = await fetch('sendmail.php',{
            method: 'POST',
            body: formData
        })
        if(response.ok){
            let result = await response.json()
            form.reset()
            form.classList.remove('nowSending')
            form.classList.add('sendingOk')
            setInterval(()=>{
                form.classList.remove('sendingOk')
            },500)
        }else{
            alert('ошибка')
            form.classList.remove('nowSending')
        }
    // }
  

}

// FORM VALIDATION -------------------------------
// function validateErrors(form){
//     let err = 0
//     let req = document.querySelectorAll('.form__item > input')
//     req.forEach((e,i)=>{
        
//         const input = e
        
//         formRemoveError(input)
//             if(input.value === ''){
//                 formAddError(input)
//                 console.log(input.parentElement)
//                 err++
//             }
        
        
//      })
//      return err;
// }
// function formAddError(input){
//     input.parentElement.classList.add('error')
//     input.classList.add('error')

// }
// function formRemoveError(input){
//     input.parentElement.classList.remove('error')
//     input.classList.remove('error')
// }




